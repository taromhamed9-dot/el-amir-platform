const Export = (() => {
  async function toExcel(data, filename) {
    if (!window.XLSX) {
      await loadScript('https://cdn.sheetjs.com/xlsx-0.20.2/package/dist/xlsx.full.min.js');
    }

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'البيانات');

    const colWidths = Object.keys(data[0] || {}).map(key => ({
      wch: Math.max(key.length, ...data.map(r => String(r[key] || '').length)) + 2
    }));
    ws['!cols'] = colWidths;

    XLSX.writeFile(wb, `${filename}.xlsx`, { bookType: 'xlsx', type: 'binary' });
    Toast.success('تم تصدير الملف بنجاح');
  }

  async function toPDF(data, columns, title, filename) {
    if (!window.html2pdf) {
      await loadScript('https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js');
    }

    const container = document.createElement('div');
    container.style.padding = '20px';
    container.style.fontFamily = "'Tajawal', sans-serif";
    container.style.direction = 'rtl';
    container.style.background = '#ffffff';

    let html = `
      <h2 style="text-align:center; color:#1a0e30; margin-bottom: 5px;">${title}</h2>
      <p style="text-align:center; color:#666; font-size: 12px; margin-bottom: 20px;">
        تاريخ الاستخراج: ${new Date().toLocaleString('ar-DZ')}
      </p>
      <table style="width:100%; border-collapse: collapse; font-size: 12px;">
        <thead>
          <tr style="background:#1a3a5c; color:white;">
            ${columns.map(c => `<th style="padding:8px; border:1px solid #ddd; text-align:right;">${c.header}</th>`).join('')}
          </tr>
        </thead>
        <tbody>
          ${data.map((row, i) => `
            <tr style="background: ${i % 2 === 0 ? '#ffffff' : '#f8fafc'}">
              ${columns.map(c => `<td style="padding:8px; border:1px solid #ddd;">${String(row[c.key] || '')}</td>`).join('')}
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;

    container.innerHTML = html;

    const opt = {
      margin:       10,
      filename:     `${filename}.pdf`,
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2, useCORS: true },
      jsPDF:        { unit: 'mm', format: 'a4', orientation: 'landscape' }
    };

    html2pdf().set(opt).from(container).save().then(() => {
      Toast.success('تم تصدير PDF بنجاح');
    }).catch(err => {
      Toast.error('فشل في تصدير PDF');
      console.error(err);
    });
  }

  function loadScript(src) {
    return new Promise((resolve, reject) => {
      if (document.querySelector(`script[src="${src}"]`)) return resolve();
      const script = document.createElement('script');
      script.src = src;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
  }

  return { toExcel, toPDF };
})();
